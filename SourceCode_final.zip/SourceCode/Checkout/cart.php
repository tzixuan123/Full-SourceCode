<?php
include 'database.php';

if(isset($_POST['update_btn'])){
	$update_value = $_POST['update_quantity'];
	$update_id = $_POST['update_quantity_id'];
	$update_quantity_query = mysqli_query($db, "UPDATE cart SET product_quantity = '$update_value' WHERE cart_id = '$update_id'");
	if($update_quantity_query){
	   header('location:cart.php');
	};
 };
 
 if(isset($_GET['remove'])){
	$remove_id = $_GET['remove'];
	mysqli_query($db, "DELETE FROM cart WHERE cart_id = '$remove_id'");
	header('location:cart.php');
 };
 
 if(isset($_GET['delete_all'])){
	mysqli_query($db, "DELETE FROM cart");
	header('location:cart.php');
 }

 if(isset($_POST['checkout'])){
	 header('location:payment.html');
 }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Shopping Cart</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="style.css" type="text/css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="master.css">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://kit.fontawesome.com/a84d485a7a.js" crossorigin="anonymous"></script>
</head>

<body>

	<?php
      
      $select_rows = mysqli_query($db, "SELECT * FROM cart") or die('query failed');
      $row_count = mysqli_num_rows($select_rows);

      ?>

	<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
		<div class="container-fluid">
		  <div class="navbar-header">
			<a class="navbar-brand" href="homepage.html">Fresh Grocer
			<img src="images/logo.png" alt="logo" class="rounded-pill">
			</a>
		  </div>
		  <ul class="navbar-nav">
		  <i class="fa-solid fa-house"></i>
		  <li><a class="nav-link" href="homepage.php">Home</a></li>
		  <li><a class="nav-link" href="products.php">Browse Our Products</a></li>
		  <li><a class="nav-link" href="contactus.php">Contact Us</a></li>
		  <li><a class="nav-link" href="aboutus.php">About Us</a></li>
		  <li><a class="nav-link active" href="cart.php">Shopping Cart</a></li>
		  <li class="nav-item dropdown">
			<a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
			  My Profile
			</a>
			<ul class="dropdown-menu dropdown-menu-dark">
			  <li><a class="dropdown-item" href="editprofile.php">Edit Profile</a></li>
			  <li><a class="dropdown-item" href="login.php">Logout</a></li>
			</ul>
	  </ul>
	  </div>
	  </nav>
	  
		<div class="cart-logo">
			<h3 class="cart-title">Shopping Cart</h3>
			</div>
		<div class="container">
	<section class="shopping_cart">
	<table>
		<thead>
         <th>Product</th>
         <th>Name</th>
         <th>Price</th>
         <th>Quantity</th>
         <th>Subtotal</th>
         <th>Action</th>
      </thead>
      <tbody>
	  	<?php 
         $select_cart = mysqli_query($db, "SELECT * FROM cart");
         $total_price = 0;
         if(mysqli_num_rows($select_cart) > 0){
            while($fetch_cart = mysqli_fetch_assoc($select_cart)){
         ?>
		<tr>
			<td><img src="food/<?php echo $fetch_cart['product_image'];?>" width="150px" height="150px"></td>
			<td><b><?php echo $fetch_cart['product_name']; ?></b></td>
			<td><b>RM <?php echo number_format($fetch_cart['product_price']); ?></b></td>
			<td>
               <form action="" method="post">
                  <input type="hidden" name="update_quantity_id" value="<?php echo $fetch_cart['cart_id']; ?>" >
                  <input type="number" name="update_quantity" min="1" value="<?php echo $fetch_cart['product_quantity']; ?>" >
                  <input type="submit" class="btn btn-dark" value="Update" name="update_btn">
               </form>   
            </td>
            <td><b>RM <?php echo $sub_total = number_format($fetch_cart['product_price'] * $fetch_cart['product_quantity']); ?></b></td>
            <td><a href="cart.php?remove=<?php echo $fetch_cart['cart_id']; ?>" onclick="return confirm('remove item from cart?')" class="btn btn-danger">
			<i class="fas fa-trash"></i> Remove</a></td>
		</tr>
		<?php
           $total_price += $sub_total;  
            };
         };
         ?>
		 <tr class="table-bottom">
            <td><a href="products.php" class="btn btn-dark"><i class="fa-solid fa-cart-shopping"></i> CONTINUE SHOPPING</a></td>
            <td colspan="3"><b>Total Price</b></td>
            <td><b>RM <?php echo $total_price; ?></b></td>
            <td><a href="cart.php?delete_all" onclick="return confirm('are you sure you want to delete all?');" class="btn btn-dark"> <i class="fas fa-trash"></i> Remove All </a></td>
         </tr>
		 </tbody>
		</table>

		<div class="checkout_btn">
			<input type="submit" class="btn btn-success w-100" name="checkout" value="CHECKOUT">
		</div>

		</section>
	</div>


</body>
</html>