<!DOCTYPE html>
<html>
    <head>
        <title>About</title>
        <meta name="description" content="This is the description">
        <link rel="stylesheet" href="css_normal/about.css" />
    </head>
    <body>
        <header class="main-header">
            <header>
                <div class="title-bar">
                <ul class="menu">
        
             <li><a href="Main.php" >Home</a></li>
            <li><a href=news.php >News</a></li>
            <li><a href="about.php" >About Us</a></li>
            <li><a href="products.php" >Store</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="login.php">Logout</a></li>
        </ul>
        </div>
    </header>
    </header>

        <section class="content-section container">
            <br><br><br>
            <h2 class="section-header">ABOUT - Phone Shop</h2>
            <img class="about-band-image" src="Images/phone%20shop%20logo.jpg">
            <p>Phone shop is an independent, privately-held company that provides information and communication technology (ICT). </p>
            <p>With integrated solutions across four key domains – telecom networks, IT, smart devices, and cloud services  – we are committed to bringing digital to every person, home and organization for a fully connected, intelligent world.</p>
            <p>Everything we develop and deliver to our customer is secure, trustworthy, and this has been consistent over a track record of 30 years.</p>
            <p>We were founded in 2020, in the southern of Malaysia, Penang. With about 21,000 RM in start-up capital. Since then, we've grown to become the world's largest supplier of telecommunication equipment and the second-largest manufacturer of smartphones. </p>
            
            
            
        </section>
        
        
        
        
    </body>
</html>