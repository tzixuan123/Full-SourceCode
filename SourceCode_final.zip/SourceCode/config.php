<?php

$conn = mysqli_connect('localhost','root','','mobilephoneshop') or die('connection failed');