

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>MainPage</title>
    <link rel="stylesheet" href="style%20home.css">
    
</head>
   <body>
       <header>
        <ul class="menu">
            <li><a href="Main.php" >Home</a></li>
            <li><a href=news.php >News</a></li>
            <li><a href="about.php" >About Us</a></li>
            <li><a href=login.php>Login</a></li>
            <li><a href="products.php" >Store</a></li>
            <li><a href="cart.php">Cart</a></li>
            
           </ul>

       </header>
    
       <div class="banner-area">
            <h2> Phone Shop</h2>
           <a href="contact%20us.php" class="btn"> Contact us</a>  
       
       
       </div>
    </body> 
   
</html>
