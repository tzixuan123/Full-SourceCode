
<?php
if(isset($_POST['submit'])){
      $email=$_POST['email'];
      $password=$_POST['password'];

      $db = mysqli_connect('localhost','root','','mobilephoneshop');

    if(empty($_POST['email'])||empty($_POST['password'])){
      echo "<script>alert('Please fill in all the details');window.location='log_admin.php';</script>";
    }
    else if($_POST['email']=="admin123@gmail.com"&&$_POST['password']=="admin123"){
      echo "<script>alert('You have successfully logged in');window.location='admin.php';</script>";
      header('location: admin.php');
    }else{
      echo "<script>alert('Wrong email or password');window.location='log_admin.php';</script>";
    }
}
?>






<!DOCTYPE html>

<html lang="en">

    <head>
    
        <title>Admin_log</title>
        <meta charset="utf-8">
        <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
        <link rel="stylesheet" href="css_normal/style%20admin.css">
                                                                                 
    </head>
    
    <body>
    
        <div class="container">
            <form action="" class="login active" method="post">
                <h2 class="title">Login-in as Admin</h2>
			<div class="form-group">
				<label for="username">Email</label>
				<div class="input-group">
					<input type="email" id="email" name="email" placeholder="Email address" required/>
					<i class='bx bx-envelope'></i>
				</div>
			</div>
			<div class="form-group">
				<label for="password">Password</label>
				<div class="input-group">
					<input type="password" pattern=".{8,}" id="password" name="password" placeholder="Your password" title="Password should be more than 8 characters">
					<i class='bx bx-lock-alt' ></i>
				</div>
				<span class="help-text">At least 8 characters</span>
			</div>
                <p>Login as User. <a href="login.php"> Login</a></p>
			<button type="submit" class="btn-submit" name="submit">Login</button>
            </form>
         </div>
    </body>
    
</html>