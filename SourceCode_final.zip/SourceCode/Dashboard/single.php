<?php include 'includes/header.php';

if (isset($_GET["id"])) {
    $post_id = $_GET["id"];
    $sql = "SELECT * FROM posts WHERE id='$post_id'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        $post_view = $row['view'] + 1;
        $update_view_sql = "UPDATE posts SET view='$post_view' WHERE id='$post_id'";
        $update_view = mysqli_query($conn, $update_view_sql);
    }
} else {
    die("<script>window.location.replace('index.php');</script>");
}

?>

        <section class="section wb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                        <div class="page-wrapper">
                            <div class="blog-title-area">
                                <span class="color-green"><a href="category.php" title="">
                                <?php
                                $sql1 = "SELECT cat_name FROM categories WHERE id='{$row["cat_id"]}'";
                                $result1 = mysqli_query($conn, $sql1);
                                if (mysqli_num_rows($result1) > 0) {
                                    $cat_data = mysqli_fetch_assoc($result1);
                                    echo $cat_data['cat_name'];
                                }
                                ?>
                                </a></span>

                                <h3><?php echo $row["title"]; ?></h3>

                                <div class="blog-meta big-meta">
                                    <small><a href="#" title=""><?php echo $row["date"]; ?></a></small>
                                    <small><a href="#" title=""><i class="fa fa-eye"></i> <?php echo $row["view"]; ?></a></small>
                                </div><!-- end meta -->
                            </div><!-- end title -->

                            <div class="single-post-media">
                                <img src="<?php if (file_exists("admin/uploads/" . $row['img'])) { echo "admin/uploads/" . $row['img']; } else { echo "admin/uploads/" . $row['old_img']; } ?>" alt="" class="img-fluid">
                            </div><!-- end media -->

                            <div class="blog-content">  
                                <div class="pp">
                                    <p><?php echo $row["description"]; ?></p>

                                </div><!-- end pp -->
                            </div><!-- end content -->                            

                            <hr class="invis1">
                        </div><!-- end page-wrapper -->
                    </div><!-- end col -->

                    
                </div><!-- end row -->
            </div><!-- end container -->
        </section>

