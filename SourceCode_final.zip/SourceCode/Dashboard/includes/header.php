<?php

include 'admin/includes/dbconfig.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'head.php'; ?>
</head>
<body>

    <div id="wrapper">
    

        <header class="header">
            <div class="container">
                <nav class="navbar navbar-inverse navbar-toggleable-md">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#Forest Timemenu" aria-controls="Forest Timemenu" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-md-center" id="Forest Timemenu">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link color-green-hover" href="http://localhost/SourceCode/news.php">Back</a></li>
                            
                            <li class="nav-item">
                                <a class="nav-link color-green-hover" href="index.php">Home</a>
                            </li>
                            <?php

                            $cat_limit = 10;
                            $sql = "SELECT * FROM categories ORDER BY cat_order LIMIT {$cat_limit}";
                            $result = mysqli_query($conn, $sql);
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {

                            ?>
                            <li class="nav-item">
                                <a class="nav-link color-green-hover" href="category.php"><?php echo $row['cat_name']; ?></a>
                            </li>
                            <?php } }
                            

                            $sql1 = "SELECT * FROM categories ORDER BY cat_order LIMIT 999999 OFFSET {$cat_limit}";
                            $result1 = mysqli_query($conn, $sql1);
                            if (mysqli_num_rows($result1) > 0) {

                            ?>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle color-green-hover" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    More
                                </a>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="border: 1px solid #eee;">
                                    <?php
                                            while ($row1 = mysqli_fetch_assoc($result1)) {
                                    ?>
                                    <a class="dropdown-item" href="#"><?php echo $row1['cat_name']; ?></a>
                                    <?php } ?>
                                </div>
                            </div>
                            <?php } ?>
                        </ul>
                    </div>
                </nav>
            </div><!-- end container -->
        </header><!-- end header -->