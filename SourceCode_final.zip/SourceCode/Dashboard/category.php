<?php include 'includes/header.php'; ?>

        <section class="section wb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                        <div class="page-wrapper">

                                <hr class="invis">

                                <div class="blog-box row">
                                    <div class="col-md-4">
                                        <div class="post-media">
                                            <a href="single.php" title="">
                                                <img src="upload/iPhone%2013%20pro.jpg" alt="" class="img-fluid">
                                                <div class="hovereffect"></div>
                                            </a>
                                        </div><!-- end media -->
                                    </div><!-- end col -->

                                    <div class="blog-meta big-meta col-md-8">
                                        <span class="bg-aqua"><a href="category.php" title="">Apple</a></span>
                                        <h4><a href="single.php" title="">iPhone 13 Pro</a></h4>
                                        <p>iPhone 13 Pro are smartphones designed, developed, and marketed by Apple Inc. They are the flagship smartphones in the fifteenth generation of the iPhone, succeeding the iPhone 12 Pro and iPhone 12 Pro Max. The devices were unveiled alongside the iPhone 13 and iPhone 13 Mini at an Apple Special Event at Apple Park in Cupertino, California on September 14, 2021. </p>
                                        <small><a href="category.php" title=""><i class="fa fa-eye"></i> 2235</a></small>
                                        <small><a href="single.php" title="">24 September, 2021</a></small>
                                        <small><a href="#" title="">iPhone</a></small>
                                    </div><!-- end meta -->
                                </div><!-- end blog-box -->

                                <hr class="invis">

                                <div class="blog-box row">
                                    <div class="col-md-4">
                                        <div class="post-media">
                                            <a href="single.php" title="">
                                                <img src="upload/iPhone%2012.png" alt="" class="img-fluid">
                                                <div class="hovereffect"></div>
                                            </a>
                                        </div><!-- end media -->
                                    </div><!-- end col -->

                                    <div class="blog-meta big-meta col-md-8">
                                        <span class="bg-aqua"><a href="category.php" title="">Apple</a></span>
                                        <h4><a href="single.php" title="">iPhone 12</a></h4>
                                        <p>iPhone 12 are a range of smartphones designed, developed, and marketed by Apple Inc. They are the fourteenth-generation, "affordable flagship" iPhones, succeeding the iPhone 11.They were unveiled at a virtually held Apple Special Event at Apple Park in Cupertino, California on October 13, 2020, alongside the "premium flagship" iPhone 12 Pro and iPhone 12 Pro Max and HomePod Mini. Pre-orders for the iPhone 12 started on October 16, 2020,  </p>
                                        <small><a href="category.php" title=""><i class="fa fa-eye"></i> 1567</a></small>
                                        <small><a href="single.php" title="">23 October,2020</a></small>
                                        <small><a href="#" title="">Apple</a></small>
                                    </div><!-- end meta -->
                                </div><!-- end blog-box -->

                                <hr class="invis">

                                <div class="blog-box row">
                                    <div class="col-md-4">
                                        <div class="post-media">
                                            <a href="single.php" title="">
                                                <img src="upload/Huawei%20p50%20pro.jpg" alt="" class="img-fluid">
                                                <div class="hovereffect"></div>
                                            </a>
                                        </div><!-- end media -->
                                    </div><!-- end col -->

                                    <div class="blog-meta big-meta col-md-8">
                                        <span class="bg-aqua"><a href="category.php" title="">Huawei</a></span>
                                        <h4><a href="single.php" title="">Huawei P50 Pro</a></h4>
                                        <p>The HUAWEI XD Optics empowers smartphone photography with better clarity while the upgraded HUAWEI XD Fusion Pro image engine helps to reproduce comprehensive image details. The main camera matrix shows you a world of true colour and the SuperZoom matrix is able to capture images in beautiful clarity, from near or far, wide or close-in.</p>
                                        <small><a href="category.php" title=""><i class="fa fa-eye"></i> 1451</a></small>
                                        <small><a href="single.php" title="">21 Jul,2021</a></small>
                                        <small><a href="#" title="">Huawei</a></small>
                                    </div><!-- end meta -->
                                </div><!-- end blog-box -->

                                <hr class="invis">

                                <div class="blog-box row">
                                    <div class="col-md-4">
                                        <div class="post-media">
                                            <a href="single.php" title="">
                                                <img src="upload/Huawei%20y7a.jpg" alt="" class="img-fluid">
                                                <div class="hovereffect"></div>
                                            </a>
                                        </div><!-- end media -->
                                    </div><!-- end col -->

                                    
                                    <div class="blog-meta big-meta col-md-8">
                                        <span class="bg-aqua"><a href="category.php" title="">Huawei</a></span>
                                        <h4><a href="single.php" title="">Huawei Y7a</a></h4>
                                        <p>There's also a side-mounted fingerprint scanner, 4G LTE connectivity, and 128GB of expandable storage. A 5,000mAh battery powers the device with support for up to 22.5W Huawei.</p>
                                        <small><a href="category.php" title=""><i class="fa fa-eye"></i> 4442</a></small>
                                        <small><a href="single.php" title="">01 Oct, 2020</a></small>
                                        <small><a href="#" title="">Huawei</a></small>
                                    </div><!-- end meta -->
                                </div><!-- end blog-box -->
                            
                            <hr class="invis">
                            
                            <div class="blog-box row">
                                    <div class="col-md-4">
                                        <div class="post-media">
                                            <a href="single.php" title="">
                                                <img src="upload/Galaxy%20Z.avif" alt="" class="img-fluid">
                                                <div class="hovereffect"></div>
                                            </a>
                                        </div><!-- end media -->
                                    </div><!-- end col -->
                                
                                    <div class="blog-meta big-meta col-md-8">
                                        <span class="bg-aqua"><a href="category.php" title="">Samsung</a></span>
                                        <h4><a href="single.php" title="">Galaxy Z</a></h4>
                                        <p>Folds into your pocket. Tucks into your purse. Slips into your skinniest jeans. Then you can take it out and it flips open into a full-screened 5G smartphone and flexes to your favorite angles.</p>
                                        <small><a href="category.php" title=""><i class="fa fa-eye"></i> 4442</a></small>
                                        <small><a href="single.php" title="">2019</a></small>
                                        <small><a href="#" title="">Samsung</a></small>
                                    </div><!-- end meta -->
                                </div><!-- end blog-box -->
                            
                            <hr class="invis">
                            
                            <div class="blog-box row">
                                    <div class="col-md-4">
                                        <div class="post-media">
                                            <a href="single.php" title="">
                                                <img src="upload/Galaxy%20Z%203.webp" alt="" class="img-fluid">
                                                <div class="hovereffect"></div>
                                            </a>
                                        </div><!-- end media -->
                                    </div><!-- end col -->
                                
                                    <div class="blog-meta big-meta col-md-8">
                                        <span class="bg-aqua"><a href="category.php" title="">Samsung</a></span>
                                        <h4><a href="single.php" title="">Galaxy Z Flip3</a></h4>
                                        <p>Silky smooth scrolling with 120Hz on the 6.7-inch Infinity Flex Display delivers smooth scrolling, swiping, dragging and dropping. It even optimizes the refresh rate based on what you're viewing.7 And with Dynamic AMOLED 2X in the mix, it's the most vivid, brightest and smoothest display in Galaxy Z ever.8,9</p>
                                        <small><a href="category.php" title=""><i class="fa fa-eye"></i> 4442</a></small>
                                        <small><a href="single.php" title="">11 August,2021</a></small>
                                        <small><a href="#" title="">Samsung</a></small>
                                    </div><!-- end meta -->
                                </div><!-- end blog-box -->
                            
                            </div><!-- end blog-list -->
                        </div><!-- end page-wrapper -->

                        <hr class="invis">

                        <div class="row">
                            <div class="col-md-12">
                                <nav aria-label="Page navigation">
                                    <ul class="pagination justify-content-start">
                                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                                        <li class="page-item">
                                            <a class="page-link" href="#">Next</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div><!-- end col -->
                        </div><!-- end row -->
                    </div><!-- end col -->

                    
                </div><!-- end row -->
            </div><!-- end container -->
        </section>
