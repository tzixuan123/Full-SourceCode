<!DOCTYPE html>
<html lang="en">

    <head>
    
    <title> News </title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css_normal/news.css">

    </head>

    <body>
    
    <header>
        
    <div class="title-bar">
        <ul class="menu">
        
             <li><a href="Main.php" >Home</a></li>
            <li><a href=news.php >News</a></li>
            <li><a href="about.php" >About Us</a></li>
            <li><a href="products.php" >Store</a></li>
            <li><a href="cart.php">Cart</a></li>
            <li><a href="login.php">Logout</a></li>
        
        </ul>
    </div>
        
    </header>
    
    <div class="intro">
        <br>
        <br>
        <br>
        <main>
            <p>The Latest product that you can find in the Phone Shop.
            <a href="Dashboard/index.php">Click for more details</a> </p>
            
        
        
        </main>
    </div>
        
    <div class="apple-container">
        <article>
        
            <h2> Apple </h2>
            <h3> <b> Iphone 13 Pro </b></h3>
            <p>The iPhone 13 display has rounded corners that follow a beautiful curved design, and these corners are within a standard rectangle. When measured as a standard rectangular shape, the screen is 6.06 inches diagonally (actual viewable area is less). </p>
            
            <img src="Images/iphone%20latest%20Pro.jpg" alt="Iphone Pro" width="250" height="300">
            
        <div class="apple-link">
            <a href="https://www.apple.com/my/iphone-13-pro/">Click for more details</a>
        </div>   
            
            <br></br>
        
        </article>
    </div> 
        
    <div class="samsung-container">
        <article>
        
            <h2> Samsung </h2>
            <h3><b> Galaxy S22 </b></h3>
            <p>Sunlight, meet Galaxy S22's bright display and Galaxy S22+'s brightest display.9 The stunning 120Hz Infinity-O Displays are built with Dynamic AMOLED 2X with Vision Booster technology for high outdoor visibility, keeping the view clear in bright daylight or at night.10 Now the only glare you'll get is from jealous strangers.</p>
            <img src="Images/S22.jpg" alt="Samsung S22" width="250" height="300">
            
            <div class="samsung-link">
            <a href="https://www.samsung.com/my/smartphones/galaxy-s22/">Click for more details</a>
        </div>
            
            <br></br>
        </article>
    </div> 
        
        
    <div class="huawei-container">
            
        <article>
        
            <h2> Huawei </h2>
            <h3><b> P50 Pocket </b></h3>
            <p> Introducing the beautiful, foldable, next generation of smart phone from HUAWEI. Experience immersive big screen views and innovative features in folded mode, giving you a versatile device to open up your world.
            </p>
            <img src="Images/p50.jpg" alt="huawei p50" width="250" height="300">
            
            <div class="huawei-link">
            <a href="https://consumer.huawei.com/my/phones/p50-pocket/specs/">Click for more details</a>
            
            </div>
            
            <br></br>
        
        </article>
    </div>
        
        
    </body>
</html>